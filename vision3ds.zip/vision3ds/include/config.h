#pragma once

/* Public web config, same values as firebase-config.js in the website. */
#define FIREBASE_API_KEY  "AIzaSyDsnT2ermdhBNEnVSIQTqBvxIw0EGJLVEo"
#define RTDB_URL          "https://test1-56ef7-default-rtdb.firebaseio.com"
#define USERNAME_DOMAIN   "@visionos.local"

#define POLL_FRAMES   300   /* ~5 s at 60 fps between automatic refreshes */
#define MSG_LIMIT     10    /* messages shown on the top screen */
#define MAX_LIST      32

/* Set to 1 ONLY to test if TLS verification fails on your console's old
 * certificate store. Leave 0 for real use. */
#define DISABLE_TLS_VERIFY 0
