#pragma once

typedef enum { NET_GET, NET_POST } net_method;

int  net_init(void);
void net_exit(void);

/* Returns HTTP status code, or -1 on transport failure.
 * *out is a malloc'd NUL-terminated body (may be NULL); caller frees. */
int net_request(net_method m, const char *url, const char *content_type,
                const char *body, char **out);
