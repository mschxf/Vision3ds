#pragma once
#include <stddef.h>
#include "config.h"

typedef struct {
    char user[64];
    char text[256];
    char when[16];
    int  mine;
} Msg;

extern char g_err[128];   /* last error, human readable */
extern char g_name[64];   /* signed-in display name */

int  v_login(const char *id, const char *pw);
void v_logout(void);
int  v_servers(char ids[][64], char names[][64]);   /* count or -1 */
int  v_channels(const char *sid, char chans[][64]); /* count or -1 */
int  v_messages(const char *sid, const char *ch, Msg *out, int max); /* count or -1 */
int  v_send(const char *sid, const char *ch, const char *text);       /* 0 or -1 */

/* Path-based variants (server channels use "messages/{sid}/{ch}", DMs use "dms/{a_b}"). */
int  v_messages_at(const char *path, Msg *out, int max);
int  v_send_at(const char *path, const char *text);
int  v_contacts(const char *node, char ids[][64], char names[][64]); /* "dmContacts" | "friends" */
void v_dm_path(const char *other_uid, char *out, size_t n);
