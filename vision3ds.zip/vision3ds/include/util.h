#pragma once
#include <stddef.h>

/* Find "key": "value" at/after p. Tolerates whitespace around the colon.
 * Returns pointer just past the value, or NULL (out is set to ""). */
const char *js_str(const char *p, const char *key, char *out, size_t n);

/* Same, but returns the LAST match of key inside [s, e). Returns 1 if found. */
int js_last_str(const char *s, const char *e, const char *key, char *out, size_t n);

/* Decode a JSON document that is just a string, e.g. "Alice". Returns 1 on success. */
int js_unquote(const char *json, char *out, size_t n);

/* Collect quoted strings. keys_only=1: object keys. keys_only=0: plain string values. */
int js_collect(const char *json, char out[][64], int max, int keys_only);

/* Split a JSON object into its member objects: fills start/end pointers. */
int js_split(const char *json, const char *st[], const char *en[], int max);

/* JSON-escape (no surrounding quotes). */
void js_escape(const char *in, char *out, size_t n);

/* Percent-encode a URL path segment. */
void urlenc(const char *in, char *out, size_t n);

/* Cut a UTF-8 string to at most maxbytes, adding ".." if shortened. */
void trunc_utf8(char *s, size_t maxbytes);
