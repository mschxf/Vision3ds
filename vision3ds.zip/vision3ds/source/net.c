#include <3ds.h>
#include <stdlib.h>
#include <string.h>
#include "net.h"
#include "config.h"

#define MAX_BODY (256 * 1024)

int net_init(void) { return R_FAILED(httpcInit(0x40000)) ? -1 : 0; }
void net_exit(void) { httpcExit(); }

static int do_request(net_method m, const char *url, const char *ctype,
                      const char *body, char **out, int depth)
{
    httpcContext ctx;
    *out = NULL;
    if (depth > 3) return -1;

    HTTPC_RequestMethod hm = (m == NET_POST) ? HTTPC_METHOD_POST : HTTPC_METHOD_GET;
    if (R_FAILED(httpcOpenContext(&ctx, hm, url, 1))) return -1;

#if DISABLE_TLS_VERIFY
    httpcSetSSLOpt(&ctx, SSLCOPT_DisableVerify);
#endif
    httpcSetKeepAlive(&ctx, HTTPC_KEEPALIVE_DISABLED);
    httpcAddRequestHeaderField(&ctx, "User-Agent", "VisionOS-3DS/0.1");
    if (body) {
        if (ctype) httpcAddRequestHeaderField(&ctx, "Content-Type", ctype);
        httpcAddPostDataRaw(&ctx, (const u32 *)body, (u32)strlen(body));
    }

    if (R_FAILED(httpcBeginRequest(&ctx))) { httpcCloseContext(&ctx); return -1; }

    u32 status = 0;
    httpcGetResponseStatusCode(&ctx, &status);

    if (status >= 300 && status < 400) {
        char loc[512];
        if (R_SUCCEEDED(httpcGetResponseHeader(&ctx, "Location", loc, sizeof loc))) {
            httpcCloseContext(&ctx);
            return do_request(m, loc, ctype, body, out, depth + 1);
        }
    }

    u32 size = 0, got = 0;
    u8 *buf = malloc(0x1000 + 1);
    if (!buf) { httpcCloseContext(&ctx); return -1; }
    Result rc;
    do {
        rc = httpcDownloadData(&ctx, buf + size, 0x1000, &got);
        size += got;
        if (rc == (Result)HTTPC_RESULTCODE_DOWNLOADPENDING) {
            if (size >= MAX_BODY) break;
            u8 *nb = realloc(buf, size + 0x1000 + 1);
            if (!nb) { free(buf); httpcCloseContext(&ctx); return -1; }
            buf = nb;
        }
    } while (rc == (Result)HTTPC_RESULTCODE_DOWNLOADPENDING);

    buf[size] = 0;
    *out = (char *)buf;
    httpcCloseContext(&ctx);
    return (int)status;
}

int net_request(net_method m, const char *url, const char *content_type,
                const char *body, char **out)
{
    return do_request(m, url, content_type, body, out, 0);
}
