#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include "config.h"
#include "net.h"
#include "util.h"
#include "vision.h"

char g_err[128];
char g_name[64];

static struct {
    char id[2048];      /* Firebase ID token */
    char refresh[512];
    char uid[64];
    time_t exp;
} S;

static void make_email(const char *in, char *out, size_t n)
{
    if (strchr(in, '@')) { snprintf(out, n, "%s", in); return; }
    char u[64];
    size_t j = 0;
    for (size_t i = 0; in[i] && j + 1 < sizeof u; i++)
        if (isalnum((unsigned char)in[i])) u[j++] = (char)tolower((unsigned char)in[i]);
    u[j] = 0;
    snprintf(out, n, "%s%s", u, USERNAME_DOMAIN);
}

static int auth_apply(const char *json, int refresh_mode)
{
    const char *k_id  = refresh_mode ? "id_token"      : "idToken";
    const char *k_ref = refresh_mode ? "refresh_token" : "refreshToken";
    const char *k_uid = refresh_mode ? "user_id"       : "localId";
    const char *k_exp = refresh_mode ? "expires_in"    : "expiresIn";
    char exp[16];
    if (!js_str(json, k_id, S.id, sizeof S.id)) return -1;
    js_str(json, k_ref, S.refresh, sizeof S.refresh);
    js_str(json, k_uid, S.uid, sizeof S.uid);
    S.exp = time(NULL) + (js_str(json, k_exp, exp, sizeof exp) ? atoi(exp) : 3000);
    return 0;
}

static int ensure_token(void)
{
    if (time(NULL) < S.exp - 120) return 0;
    char url[160], body[600], *r = NULL;
    snprintf(url, sizeof url, "https://securetoken.googleapis.com/v1/token?key=%s", FIREBASE_API_KEY);
    snprintf(body, sizeof body, "grant_type=refresh_token&refresh_token=%s", S.refresh);
    int st = net_request(NET_POST, url, "application/x-www-form-urlencoded", body, &r);
    int ok = (st == 200 && r && auth_apply(r, 1) == 0) ? 0 : -1;
    free(r);
    if (ok != 0) snprintf(g_err, sizeof g_err, "Session expired. Sign in again.");
    return ok;
}

static int db_get(const char *path, const char *query, char **out)
{
    *out = NULL;
    if (ensure_token() != 0) return -1;
    static char url[3072];
    snprintf(url, sizeof url, "%s/%s.json?%s%sauth=%s", RTDB_URL, path,
             query, query[0] ? "&" : "", S.id);
    int st = net_request(NET_GET, url, NULL, NULL, out);
    if (st < 0) snprintf(g_err, sizeof g_err, "Network error. Check Wi-Fi.");
    else if (st != 200) {
        char why[64] = "";
        if (*out) js_str(*out, "error", why, sizeof why);
        snprintf(g_err, sizeof g_err, "Load failed (%d) %s", st, why);
    }
    return st;
}

int v_login(const char *id, const char *pw)
{
    char email[160], e[200], p[200], body[512], url[160], *r = NULL;
    make_email(id, email, sizeof email);
    js_escape(email, e, sizeof e);
    js_escape(pw, p, sizeof p);
    snprintf(body, sizeof body,
             "{\"email\":\"%s\",\"password\":\"%s\",\"returnSecureToken\":true}", e, p);
    snprintf(url, sizeof url,
             "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=%s",
             FIREBASE_API_KEY);
    int st = net_request(NET_POST, url, "application/json", body, &r);
    memset(body, 0, sizeof body);
    memset(p, 0, sizeof p);

    if (st == 200 && r && auth_apply(r, 0) == 0) {
        free(r);
        char path[100], *nm = NULL;
        g_name[0] = 0;
        snprintf(path, sizeof path, "users/%s/name", S.uid);
        if (db_get(path, "", &nm) == 200 && nm) js_unquote(nm, g_name, sizeof g_name);
        free(nm);
        if (!g_name[0]) snprintf(g_name, sizeof g_name, "3DS user");
        return 0;
    }
    char why[96] = "";
    if (r) js_str(r, "message", why, sizeof why);
    free(r);
    if (st < 0)
        snprintf(g_err, sizeof g_err, "Can't reach server (Wi-Fi or TLS)");
    else if (strstr(why, "INVALID") || strstr(why, "NOT_FOUND") || strstr(why, "PASSWORD"))
        snprintf(g_err, sizeof g_err, "Wrong username or password");
    else
        snprintf(g_err, sizeof g_err, "Login failed (%d) %s", st, why);
    return -1;
}

void v_logout(void)
{
    memset(&S, 0, sizeof S);
    g_name[0] = 0;
}

int v_servers(char ids[][64], char names[][64])
{
    char path[100], *r = NULL;
    snprintf(path, sizeof path, "users/%s/serverIds", S.uid);
    if (db_get(path, "", &r) != 200 || !r) { free(r); return -1; }
    const char *b = r;
    while (*b == ' ') b++;
    /* serverIds may be an object {"id":true} or an array ["id"] */
    int n = js_collect(r, ids, MAX_LIST, *b == '{');
    free(r);
    for (int i = 0; i < n; i++) {
        char sp[160], enc[100], *nm = NULL;
        urlenc(ids[i], enc, sizeof enc);
        snprintf(sp, sizeof sp, "servers/%s/name", enc);
        names[i][0] = 0;
        if (db_get(sp, "", &nm) == 200 && nm) js_unquote(nm, names[i], 64);
        free(nm);
        if (!names[i][0]) snprintf(names[i], 64, "%s", ids[i]);
    }
    return n;
}

int v_channels(const char *sid, char chans[][64])
{
    char path[160], enc[100], *r = NULL;
    urlenc(sid, enc, sizeof enc);
    snprintf(path, sizeof path, "servers/%s/channels", enc);
    int n = -1;
    if (db_get(path, "shallow=true", &r) == 200 && r)
        n = js_collect(r, chans, MAX_LIST, 1);
    free(r);
    return n;
}

int v_messages_at(const char *path, Msg *out, int max)
{
    char q[64], *r = NULL;
    snprintf(q, sizeof q, "orderBy=%%22%%24key%%22&limitToLast=%d", max);
    if (db_get(path, q, &r) != 200 || !r) { free(r); return -1; }

    const char *st[MSG_LIMIT + 2], *en[MSG_LIMIT + 2];
    int cnt = js_split(r, st, en, max + 2);
    int first = cnt > max ? cnt - max : 0, n = 0;
    for (int i = first; i < cnt; i++) {
        Msg *m = &out[n];
        char uid[64] = "";
        memset(m, 0, sizeof *m);
        /* Fields are alphabetical (text, time, uid, user); nested reply data comes
         * earlier, so the LAST match of each key is the message's own. */
        js_last_str(st[i], en[i], "text", m->text, sizeof m->text);
        js_last_str(st[i], en[i], "time", m->when, sizeof m->when);
        js_last_str(st[i], en[i], "uid", uid, sizeof uid);
        if (!js_last_str(st[i], en[i], "user", m->user, sizeof m->user))
            snprintf(m->user, sizeof m->user, "?");
        if (!m->text[0]) snprintf(m->text, sizeof m->text, "[attachment]");
        m->mine = (strcmp(uid, S.uid) == 0);
        n++;
    }
    free(r);
    return n;
}

int v_send_at(const char *path, const char *text)
{
    char t[600], u[140], body[1024], clk[16], *r = NULL;
    static char url[3072];
    if (ensure_token() != 0) return -1;
    js_escape(text, t, sizeof t);
    js_escape(g_name, u, sizeof u);
    time_t now = time(NULL);
    strftime(clk, sizeof clk, "%I:%M %p", localtime(&now));
    snprintf(body, sizeof body,
             "{\"user\":\"%s\",\"uid\":\"%s\",\"photoURL\":\"\",\"text\":\"%s\",\"time\":\"%s\","
             "\"createdAt\":{\".sv\":\"timestamp\"},\"expiresAt\":%lld}",
             u, S.uid, t, clk, ((long long)now + 3LL * 86400LL) * 1000LL);
    snprintf(url, sizeof url, "%s/%s.json?auth=%s", RTDB_URL, path, S.id);
    int st = net_request(NET_POST, url, "application/json", body, &r);
    if (st != 200) {
        char why[64] = "";
        if (r) js_str(r, "error", why, sizeof why);
        if (st < 0) snprintf(g_err, sizeof g_err, "Network error. Check Wi-Fi.");
        else snprintf(g_err, sizeof g_err, "Send failed (%d) %s", st, why);
        free(r);
        return -1;
    }
    free(r);
    return 0;
}

int v_messages(const char *sid, const char *ch, Msg *out, int max)
{
    char es[100], ec[100], path[256];
    urlenc(sid, es, sizeof es);
    urlenc(ch, ec, sizeof ec);
    snprintf(path, sizeof path, "messages/%s/%s", es, ec);
    return v_messages_at(path, out, max);
}

int v_send(const char *sid, const char *ch, const char *text)
{
    char es[100], ec[100], path[256];
    urlenc(sid, es, sizeof es);
    urlenc(ch, ec, sizeof ec);
    snprintf(path, sizeof path, "messages/%s/%s", es, ec);
    return v_send_at(path, text);
}

/* node: "dmContacts" or "friends". Lists uids under node/{myuid} with display names. */
int v_contacts(const char *node, char ids[][64], char names[][64])
{
    char path[120], *r = NULL;
    snprintf(path, sizeof path, "%s/%s", node, S.uid);
    if (db_get(path, "shallow=true", &r) != 200 || !r) { free(r); return -1; }
    int n = js_collect(r, ids, MAX_LIST, 1);
    free(r);
    for (int i = 0; i < n; i++) {
        char sp[160], enc[100], *nm = NULL;
        urlenc(ids[i], enc, sizeof enc);
        snprintf(sp, sizeof sp, "users/%s/name", enc);
        names[i][0] = 0;
        if (db_get(sp, "", &nm) == 200 && nm) js_unquote(nm, names[i], 64);
        free(nm);
        if (!names[i][0]) snprintf(names[i], 64, "User");
    }
    return n;
}

/* DM conversation path: dms/{sortedUid1_sortedUid2} */
void v_dm_path(const char *other, char *out, size_t n)
{
    const char *a = S.uid, *b = other;
    char ea[100], eb[100];
    if (strcmp(a, b) > 0) { a = other; b = S.uid; }
    urlenc(a, ea, sizeof ea);
    urlenc(b, eb, sizeof eb);
    snprintf(out, n, "dms/%s_%s", ea, eb);
}
