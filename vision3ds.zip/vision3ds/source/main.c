#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "config.h"
#include "net.h"
#include "util.h"
#include "vision.h"

/* ---------- look & feel ---------- */

#define Z 0.5f   /* every draw uses the same depth, so call order decides overlap */
#define COL(r, g, b) C2D_Color32(r, g, b, 255)
#define C_BG     COL(30, 31, 34)
#define C_PANEL  COL(43, 45, 49)
#define C_PANEL2 COL(64, 66, 73)
#define C_ACCENT accent
#define C_TEXT   COL(242, 243, 245)
#define C_MUTED  COL(148, 155, 164)
#define C_RED    COL(200, 60, 64)

#define TS    0.47f    /* message text scale */
#define MAXL  6        /* max wrapped lines per message */
#define TEXTW 320.0f   /* max bubble text width */

static u32 accent;

typedef enum { ST_LOGIN, ST_MENU, ST_SERVERS, ST_CHANNELS, ST_LIST, ST_CHAT, ST_SETTINGS } State;
typedef struct { float x, y, w, h; } Rc;
typedef struct { float scroll; int sel; } LS;
typedef struct { Msg m; C2D_Text lines[MAXL]; int nl; float w; } MV;

static C3D_RenderTarget *topT, *botT;
static C2D_TextBuf frameBuf, layBuf, scratchBuf;
static float lineH = 14, spaceW = 4;

static State st = ST_LOGIN;
static char sids[MAX_LIST][64], snames[MAX_LIST][64], chans[MAX_LIST][64];
static int ns, nc, curS, curC;
static LS lsS, lsC;
static Msg msgs[MSG_LIMIT];
static MV mv[MSG_LIMIT];
static int nmv, off, pollT;
static char label[140];
static char notice[128], busyMsg[48];
static int noticeT;
static char chatPath[256];
static State chatBack = ST_CHANNELS;
static char lids[MAX_LIST][64], lnames[MAX_LIST][64];
static int lcount, listMode;   /* listMode 0 = messages, 1 = friends */
static LS lsL;

static const Rc backRc    = {0, 0, 76, 28};
static const Rc loginRc   = {50, 104, 220, 60};
static const Rc writeRc   = {20, 44, 280, 60};
static const Rc refreshRc = {20, 120, 130, 48};
static const Rc upRc      = {158, 120, 68, 48};
static const Rc downRc    = {232, 120, 68, 48};

/* ---------- input (touch taps + drag scrolling) ---------- */

static struct { u32 kd; int tap, tx, ty, down, dragging, sy, lx, ly, dy; } In;

static void input_update(void)
{
    hidScanInput();
    u32 kd = hidKeysDown(), kh = hidKeysHeld(), ku = hidKeysUp();
    In.kd = kd;
    In.tap = 0;
    In.dy = 0;
    if (kh & KEY_TOUCH) {
        touchPosition tp;
        hidTouchRead(&tp);
        if (kd & KEY_TOUCH) {
            In.sy = tp.py; In.lx = tp.px; In.ly = tp.py;
            In.down = 1; In.dragging = 0;
        } else {
            In.dy = tp.py - In.ly;
            In.lx = tp.px; In.ly = tp.py;
            if (abs(tp.py - In.sy) > 6) In.dragging = 1;
        }
    }
    if ((ku & KEY_TOUCH) && In.down) {
        In.down = 0;
        if (!In.dragging) { In.tap = 1; In.tx = In.lx; In.ty = In.ly; }
    }
}

static int hit(Rc r)
{
    return In.tap && In.tx >= r.x && In.tx < r.x + r.w && In.ty >= r.y && In.ty < r.y + r.h;
}

/* ---------- drawing helpers ---------- */

static float tw(const char *s, float sc)
{
    C2D_Text t;
    float w = 0, h = 0;
    C2D_TextBufClear(scratchBuf);
    C2D_TextParse(&t, scratchBuf, s);
    C2D_TextGetDimensions(&t, sc, sc, &w, &h);
    return w;
}

static void tdraw(const char *s, float x, float y, float sc, u32 col)
{
    C2D_Text t;
    C2D_TextParse(&t, frameBuf, s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, Z, sc, sc, col);
}

static void tcenter(const char *s, float cx, float y, float sc, u32 col)
{
    tdraw(s, cx - tw(s, sc) / 2, y, sc, col);
}

static void rrect(float x, float y, float w, float h, float r, u32 c)
{
    if (r * 2 > h) r = h / 2;
    if (r * 2 > w) r = w / 2;
    C2D_DrawRectSolid(x + r, y, Z, w - 2 * r, h, c);
    C2D_DrawRectSolid(x, y + r, Z, r, h - 2 * r, c);
    C2D_DrawRectSolid(x + w - r, y + r, Z, r, h - 2 * r, c);
    C2D_DrawCircleSolid(x + r, y + r, Z, r, c);
    C2D_DrawCircleSolid(x + w - r, y + r, Z, r, c);
    C2D_DrawCircleSolid(x + r, y + h - r, Z, r, c);
    C2D_DrawCircleSolid(x + w - r, y + h - r, Z, r, c);
}

static void button(Rc r, const char *text, u32 col)
{
    rrect(r.x, r.y, r.w, r.h, 9, col);
    tcenter(text, r.x + r.w / 2, r.y + r.h / 2 - 9, 0.55f, C_TEXT);
}

static void avatar(float cx, float cy, float r, const char *name)
{
    unsigned h = 0;
    u32 c;
    for (const char *p = name; *p; p++) h = h * 31 + (unsigned char)*p;
    switch (h % 6) {
    case 0: c = COL(88, 101, 242); break;
    case 1: c = COL(35, 165, 90); break;
    case 2: c = COL(235, 69, 158); break;
    case 3: c = COL(220, 160, 40); break;
    case 4: c = COL(0, 160, 190); break;
    default: c = COL(160, 100, 230); break;
    }
    C2D_DrawCircleSolid(cx, cy, Z, r, c);

    char ini[5] = {0};
    unsigned char b = (unsigned char)name[0];
    int l = b >= 0xF0 ? 4 : b >= 0xE0 ? 3 : b >= 0xC0 ? 2 : 1;
    for (int i = 0; i < l && name[i]; i++) ini[i] = name[i];
    if (!ini[0]) ini[0] = '?';
    if (ini[0] >= 'a' && ini[0] <= 'z') ini[0] -= 32;
    tcenter(ini, cx, cy - r * 0.82f, r * 0.045f, C_TEXT);
}

/* ---------- message layout (done once per fetch, not per frame) ---------- */

static float wordw(const char *w, int len)
{
    char tmp[64];
    if (len > 63) len = 63;
    memcpy(tmp, w, len);
    tmp[len] = 0;
    return tw(tmp, TS);
}

static void push_line(MV *v, const char *line)
{
    if (v->nl >= MAXL) return;
    C2D_TextParse(&v->lines[v->nl], layBuf, line);
    C2D_TextOptimize(&v->lines[v->nl]);
    v->nl++;
}

static void layout_msg(MV *v)
{
    char line[320];
    int ll = 0;
    float lw = 0, maxlw = 0;
    const char *p = v->m.text;
    v->nl = 0;
    line[0] = 0;

    while (*p) {
        while (*p == ' ') p++;
        const char *ws = p;
        while (*p && *p != ' ') p++;
        int wl = (int)(p - ws);
        if (wl <= 0) break;
        if (wl > 40) {
            wl = 40;
            while (wl > 0 && ((unsigned char)ws[wl] & 0xC0) == 0x80) wl--;
        }
        float ww = wordw(ws, wl);
        if (ll > 0 && lw + spaceW + ww > TEXTW) {
            push_line(v, line);
            if (lw > maxlw) maxlw = lw;
            ll = 0; lw = 0; line[0] = 0;
            if (v->nl >= MAXL) break;
        }
        if (ll > 0) { line[ll++] = ' '; lw += spaceW; }
        memcpy(line + ll, ws, wl);
        ll += wl;
        line[ll] = 0;
        lw += ww;
    }
    if (ll > 0 && v->nl < MAXL) { push_line(v, line); if (lw > maxlw) maxlw = lw; }
    if (v->nl == 0) push_line(v, " ");
    v->w = maxlw < 20 ? 20 : maxlw;
}

static void relayout(void)
{
    C2D_TextBufClear(layBuf);
    for (int i = 0; i < nmv; i++) {
        mv[i].m = msgs[i];
        layout_msg(&mv[i]);
    }
}

/* ---------- UI actions ---------- */

static void toast(const char *m)
{
    snprintf(notice, sizeof notice, "%s", m);
    trunc_utf8(notice, 48);
    noticeT = 240;
}

static void draw_top(void);
static void draw_bottom(void)
{
    switch (st) {
    case ST_LOGIN:
        tcenter("Welcome back", 160, 40, 0.85f, C_TEXT);
        tcenter("Use your Vision account", 160, 78, 0.5f, C_MUTED);
        button(loginRc, "Sign in", C_ACCENT);
        tcenter("Tap, or press A", 160, 178, 0.45f, C_MUTED);
        break;
    case ST_MENU:
        for (int i = 0; i < 4; i++) {
            Rc r = tiles[i];
            rrect(r.x, r.y, r.w, r.h, 12, i == menuSel ? C_PANEL2 : C_PANEL);
            C2D_DrawCircleSolid(r.x + r.w / 2, r.y + 30, Z, 18, C_ACCENT);
            tcenter(tileIcon[i], r.x + r.w / 2, r.y + 16, 0.8f, C_TEXT);
            tcenter(tileName[i], r.x + r.w / 2, r.y + 56, 0.55f, C_TEXT);
        }
        header("Menu", 0, 320);
        break;
    case ST_SERVERS:
        list_draw(&lsS, snames, ns, 44, 28, 1);
        header("Servers", 1, 320);
        break;
    case ST_CHANNELS: {
        list_draw(&lsC, chans, nc, 38, 28, 0);
        char t[64];
        snprintf(t, sizeof t, "%s", snames[curS]);
        trunc_utf8(t, 22);
        header(t, 1, 320);
        break;
    }
    case ST_LIST:
        list_draw(&lsL, lnames, lcount, 44, 28, 1);
        header(listMode ? "Friends" : "Messages", 1, 320);
        if (listMode) tdraw("tap to chat", 240, 8, 0.4f, C_MUTED);
        break;
    case ST_SETTINGS:
        header("Settings", 1, 320);
        tdraw("Accent color  (L / R)", 20, 36, 0.5f, C_MUTED);
        for (int i = 0; i < 6; i++) {
            float cx = 35 + i * 50;
            if (i == accentIdx) C2D_DrawCircleSolid(cx, 70, Z, 21, C_TEXT);
            C2D_DrawCircleSolid(cx, 70, Z, 17, swatch(i));
        }
        tdraw("Chat", 20, 96, 0.5f, C_MUTED);
        button(pollRc, pollLbl[pollIdx], C_PANEL2);
        button(outRc, "Sign out", C_RED);
        break;
    case ST_CHAT:
        header(label, 1, 320);
        button(writeRc, "Write a message", C_ACCENT);
        button(refreshRc, "Refresh", C_PANEL2);
        button(upRc, "Older", C_PANEL2);
        button(downRc, "Newer", C_PANEL2);
        tcenter("A: write   Y: refresh   D-pad: scroll", 160, 186, 0.42f, C_MUTED);
        break;
    }
    if (noticeT > 0) {
        rrect(10, 200, 300, 30, 9, C_RED);
        tcenter(notice, 160, 206, 0.5f, C_TEXT);
    }
}

/* ---------- main ---------- */

int main(void)
{
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    topT = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    botT = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    frameBuf   = C2D_TextBufNew(4096);
    layBuf     = C2D_TextBufNew(8192);
    scratchBuf = C2D_TextBufNew(256);

    {
        C2D_Text t;
        float w = 0, h = 0;
        C2D_TextParse(&t, scratchBuf, "Ag");
        C2D_TextGetDimensions(&t, TS, TS, &w, &h);
        if (h > 8) lineH = h;
        float sw = tw("a a", TS) - tw("aa", TS);
        if (sw > 1) spaceW = sw;
    }

    load_cfg();
    int net_ok = (net_init() == 0);
    if (!net_ok) toast("HTTP init failed");

    while (aptMainLoop()) {
        input_update();
        if (In.kd & KEY_START) break;
        update();
        render();
    }

    C2D_TextBufDelete(frameBuf);
    C2D_TextBufDelete(layBuf);
    C2D_TextBufDelete(scratchBuf);
    C2D_Fini();
    C3D_Fini();
    if (net_ok) net_exit();
    gfxExit();
    return 0;
}
