#include <stdio.h>
#include <string.h>
#include "util.h"

static const char *skip_ws(const char *p)
{
    while (*p == ' ' || *p == '\n' || *p == '\t' || *p == '\r') p++;
    return p;
}

static void put_cp(char *out, size_t n, size_t *i, unsigned cp)
{
    char b[4];
    int l;
    if (cp < 32) cp = ' ';
    if (cp >= 0xD800 && cp <= 0xDFFF) cp = '?';   /* emoji surrogates: not supported */
    if (cp < 0x80) { b[0] = (char)cp; l = 1; }
    else if (cp < 0x800) { b[0] = (char)(0xC0 | (cp >> 6)); b[1] = (char)(0x80 | (cp & 63)); l = 2; }
    else { b[0] = (char)(0xE0 | (cp >> 12)); b[1] = (char)(0x80 | ((cp >> 6) & 63)); b[2] = (char)(0x80 | (cp & 63)); l = 3; }
    if (*i + l < n) { memcpy(out + *i, b, l); *i += l; }
}

/* p points at the opening quote. Returns pointer after the closing quote. */
static const char *read_str(const char *p, char *out, size_t n)
{
    size_t i = 0;
    p++;
    while (*p && *p != '"') {
        if (*p == '\\') {
            p++;
            char e = *p;
            if (!e) break;
            p++;
            if (e == 'u') {
                unsigned v = 0;
                for (int k = 0; k < 4 && *p; k++, p++) {
                    char h = *p;
                    v <<= 4;
                    if (h >= '0' && h <= '9') v |= h - '0';
                    else if ((h | 32) >= 'a' && (h | 32) <= 'f') v |= (h | 32) - 'a' + 10;
                }
                put_cp(out, n, &i, v);
            } else if (e == 'n' || e == 't' || e == 'r') {
                put_cp(out, n, &i, ' ');
            } else {
                put_cp(out, n, &i, (unsigned char)e);
            }
        } else {
            if (i + 1 < n) out[i++] = *p;   /* raw UTF-8 bytes pass through */
            p++;
        }
    }
    if (*p == '"') p++;
    if (n) out[i] = 0;
    return p;
}

const char *js_str(const char *p, const char *key, char *out, size_t n)
{
    char needle[96];
    snprintf(needle, sizeof needle, "\"%s\"", key);
    while (p && (p = strstr(p, needle))) {
        p += strlen(needle);
        const char *q = skip_ws(p);
        if (*q == ':') {
            q = skip_ws(q + 1);
            if (*q == '"') return read_str(q, out, n);
        }
    }
    if (n) out[0] = 0;
    return NULL;
}

int js_last_str(const char *s, const char *e, const char *key, char *out, size_t n)
{
    char tmp[512];
    int found = 0;
    const char *p = s, *q;
    while (p < e && (q = js_str(p, key, tmp, sizeof tmp)) && q <= e) {
        snprintf(out, n, "%s", tmp);
        found = 1;
        p = q;
    }
    return found;
}

int js_unquote(const char *json, char *out, size_t n)
{
    const char *q = skip_ws(json);
    if (*q != '"') { if (n) out[0] = 0; return 0; }
    read_str(q, out, n);
    return 1;
}

int js_collect(const char *json, char out[][64], int max, int keys_only)
{
    int n = 0;
    const char *p = json;
    while (*p && n < max) {
        if (*p == '"') {
            char tmp[64];
            const char *e = read_str(p, tmp, sizeof tmp);
            int is_key = (*skip_ws(e) == ':');
            if (is_key == keys_only && tmp[0]) strcpy(out[n++], tmp);
            p = e;
        } else {
            p++;
        }
    }
    return n;
}

int js_split(const char *json, const char *st[], const char *en[], int max)
{
    int n = 0, depth = 0;
    const char *p = json, *start = NULL;
    while (*p && n < max) {
        if (*p == '"') {
            p++;
            while (*p && *p != '"') { if (*p == '\\' && p[1]) p++; p++; }
            if (*p) p++;
            continue;
        }
        if (*p == '{') { depth++; if (depth == 2) start = p; }
        else if (*p == '}') {
            if (depth == 2 && start) { st[n] = start; en[n] = p + 1; n++; start = NULL; }
            depth--;
        }
        p++;
    }
    return n;
}

void js_escape(const char *in, char *out, size_t n)
{
    size_t i = 0;
    for (; *in && i + 7 < n; in++) {
        unsigned char c = (unsigned char)*in;
        if (c == '"' || c == '\\') { out[i++] = '\\'; out[i++] = (char)c; }
        else if (c < 32) { out[i++] = ' '; }
        else out[i++] = (char)c;
    }
    out[i] = 0;
}

void urlenc(const char *in, char *out, size_t n)
{
    static const char *hex = "0123456789ABCDEF";
    size_t i = 0;
    for (; *in && i + 4 < n; in++) {
        unsigned char c = (unsigned char)*in;
        if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') ||
            (c >= 'A' && c <= 'Z') || c == '-' || c == '_' || c == '.' || c == '~')
            out[i++] = (char)c;
        else { out[i++] = '%'; out[i++] = hex[c >> 4]; out[i++] = hex[c & 15]; }
    }
    out[i] = 0;
}

void trunc_utf8(char *s, size_t maxbytes)
{
    size_t len = strlen(s);
    if (len <= maxbytes) return;
    size_t cut = maxbytes;
    while (cut > 0 && ((unsigned char)s[cut] & 0xC0) == 0x80) cut--;
    s[cut] = 0;
    strcat(s, "..");
}
