# VisionOS for 3DS (v0.3, menus)

Native Old 3DS XL client for the existing Vision Firebase backend. Same accounts, same database paths.

## What it looks like
- Dark theme (Discord-style): rounded message bubbles, colored letter avatars, timestamps
- **Top screen:** the chat. Your messages are accent-colored bubbles on the right, others on the left
- **Bottom screen:** touch UI. Big buttons, scrollable server and channel lists (drag to scroll, tap to open)
- Controls: touch, or D-pad + A (select/write), B (back), Y (refresh), START (quit)

## Menus
- **Main menu** (after sign-in): Servers, Messages, Friends, Settings tiles (touch, or D-pad + A)
- **Servers:** servers, then channels, then chat
- **Messages:** your DM contacts. **Friends:** your friends list; tap one to open a DM
- **Settings:** accent color (tap a swatch, or L/R), auto-refresh Off / 5 / 10 / 30 s, Sign out.
  Saved to `sdmc:/vision3ds.cfg`

## What works
- Sign in with username or email + password, with automatic token refresh
- Server list, channel list, last 10 messages, send text, auto-refresh every ~5 s
- Messages use the same fields as the website

## Not yet built
Friend requests, blocking, GIFs, photo capture/upload, image display, profile pictures (avatars are
colored letter circles for now), saved login. Network calls still block the UI for a moment;
a "Loading..." overlay is shown meanwhile.

## Build (.3dsx)
1. Install devkitPro with the `3ds-dev` group (includes citro2d / citro3d).
2. `cd vision3ds && make`
3. Copy `vision3ds.3dsx` to `sdmc:/3ds/` and run from the Homebrew Launcher.

## Build (.cia)
1. Install `makerom` and `bannertool` (both are on GitHub; put them on your PATH).
2. Put your icon at `resources/icon.png` (48x48 PNG). Without it, the default icon is used.
3. `make cia` produces `vision3ds.cia`.

The banner (`resources/banner.png`), silent banner audio and `resources/vision.rsf` are included.
If `makerom` rejects the `.rsf`, copy the app `.rsf` from the devkitPro 3ds-examples templates
and keep only the `Title`, `ProductCode` and `UniqueId` values from ours.

## Install by QR code (FBI)
1. Upload `vision3ds.cia` to Google Drive and set sharing to "Anyone with the link".
2. Turn the share link into a direct link:
   `https://drive.google.com/uc?export=download&id=FILE_ID`
3. Make a QR code of that direct link. On the 3DS: FBI, Remote Install, Scan QR Code.
   Drive may not work with FBI (old TLS and redirects); if so, host it on GitHub Releases
   or use "Receive URLs over the network" in FBI.

## Things to check on hardware
- **TLS:** the Old 3DS certificate store is old. If sign-in says "Can't reach server", try
  `DISABLE_TLS_VERIFY 1` in `include/config.h` only to confirm the cause. Do not ship with it on.
- **`serverIds` shape:** handled as an object or an array.
- **Message rules:** `expiresAt` is sent as a number (ms). Adjust `v_send()` in `source/vision.c`
  if your rules expect something else.
- **Emoji:** the system font shows most text, but emoji outside the basic plane show as `?`.
- This code has not been compiled (no devkitPro in the build environment). Expect to fix a few
  small compile errors on the first `make`, especially around citro2d calls.
